package com.eurotech.reliagate.io.ignition;

import java.io.IOException;

import com.eurotech.framework.EsfException;

public interface IgnitionService {

	public boolean isIgnitionOn() throws IOException, EsfException;
}
