package com.eurotech.reliagate.io.adc;

import java.io.IOException;

import com.eurotech.framework.EsfException;

public interface AdcReaderService {

	public float getVoltage(Adc adc) throws IOException, EsfException;
}
