package com.eurotech.reliagate.io.monitor;

import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.eurotech.framework.EsfException;
import com.eurotech.framework.cloud.CloudClient;
import com.eurotech.framework.cloud.CloudClientListener;
import com.eurotech.framework.cloud.CloudService;
import com.eurotech.framework.configuration.ConfigurableComponent;
import com.eurotech.framework.message.EsfPayload;
import com.eurotech.framework.position.NmeaPosition;
import com.eurotech.framework.position.PositionService;
import com.eurotech.reliagate.io.adc.Adc;
import com.eurotech.reliagate.io.adc.AdcReaderService;
import com.eurotech.reliagate.io.ignition.IgnitionService;
import com.eurotech.reliagate.io.leds.Led;
import com.eurotech.reliagate.io.leds.LedService;
import com.eurotech.reliagate.io.leds.LedState;

public class ReliagateIOMonitor implements ConfigurableComponent, CloudClientListener {
	
	private static final Logger s_logger = LoggerFactory.getLogger(ReliagateIOMonitor.class);
	
	private static final String APP_ID = ReliagateIOMonitor.class.getName();
	
	private static final String POLL_INTERVAL_PROP_NAME = "poll.interval";
	private static final String USE_ADC_PROP_NAME = "use.adc";
	private static final String BATTERY_UNDERVOLTAGE_THRESHOLD_PROP_NAME = "battery.undervoltage.threshold";
	private static final String NORMAL_SHUTDOWN_DELAY_PROP_NAME = "normal.shutdown.delay";
	private static final String PUBLISH_ENABLED_PROP_NAME = "publish.enabled";
	private static final String PUBLISH_TOPIC_PROP_NAME  = "publish.semanticTopic";
	private static final String PUBLISH_QOS_PROP_NAME    = "publish.qos";
	private static final String PUBLISH_RETAIN_PROP_NAME = "publish.retain";
	
	private static final String METRICS_IS_IGNITION_ON = "isIgnitionOn";
	private static final String METRICS_IS_UNDERVOLTAGE = "isUndervoltage";
	private static final String METRICS_BATERY_VOLTAGE = "batteryVoltage";
	private static final String METRICS_POSITION_LATITUDE = "lattitude";
	private static final String METRICS_POSITION_LONGITUDE = "longitude";
	private static final String METRICS_POSITION_SPEED_MPH = "speedMph";
		
	private static final int DFLT_POLL_INTERVAL = 2; // in seconds
	private static final Adc DFLT_USE_ADC = Adc.One;
	private static final int DFLT_NORMAL_SHUTDOWN_DELAY = 1800; // in seconds
	private static final float DFLT_BATTERY_UNDERVOLTAGE_THRESHOLD = 10.5f;
	private static final boolean DFLT_PUBLISH_ENABLED = true;
	private static final String DFLT_PUBLISH_SEMANTIC_TOPIC = "data";
	private static final int DFLT_PUBLISH_QOS = 0;
	private static final boolean DFLT_PUBLISH_RETAIN = false;
	
	private CloudService m_cloudService;
	private CloudClient m_cloudClient;
	private PositionService m_positionService;
	
	private LedService m_reliagateLed;
	private IgnitionService m_ignitionSensor;
	private AdcReaderService m_adcReader;
	
	private ScheduledFuture<?>  m_monitorTask = null;
	private ScheduledFuture<?>  m_delayedShutdownTask = null;
	
	private boolean m_isIgnitionOn = false;
	private boolean m_isUnderVoltage = false;

	private int m_configPollInterval = DFLT_POLL_INTERVAL;
	private Adc m_useAdc = DFLT_USE_ADC;
	private int m_configNormalShutdownDelay = DFLT_NORMAL_SHUTDOWN_DELAY;
	private float m_configBatteryUndervoltageThreshold = DFLT_BATTERY_UNDERVOLTAGE_THRESHOLD;
	private boolean m_configPublishEnabled = DFLT_PUBLISH_ENABLED;
	private String m_configPublishSemanticTopic = DFLT_PUBLISH_SEMANTIC_TOPIC;
	private int m_configPublishQos = DFLT_PUBLISH_QOS;
	private boolean m_configPublishRetain = DFLT_PUBLISH_RETAIN;
		
	// ----------------------------------------------------------------
	//
	// Dependencies
	//
	// ----------------------------------------------------------------
	public void setAdcReaderService(AdcReaderService adcService) {
		s_logger.info("setReliagateIgnitionService()");
		m_adcReader = adcService;
	}

	public void unsetAdcReaderService(AdcReaderService adcService) {
		s_logger.info("unsetReliagateIgnitionService()");
		m_adcReader = null;
	}
	
	public void setIgnitionService(IgnitionService ignitionService) {
		s_logger.info("setReliagateIgnitionService()");
		m_ignitionSensor = ignitionService;
	}

	public void unsetIgnitionService(IgnitionService ignitionService) {
		s_logger.info("unsetReliagateIgnitionService()");
		m_ignitionSensor = null;
	}

	public void setLedService(LedService ledService) {
		s_logger.info("setReliagateLedService()");
		m_reliagateLed = ledService;
	}

	public void unsetLedService(LedService ledService) {
		s_logger.info("unsetReliagateLedService()");
		m_reliagateLed = null;
	}
		
	public void setCloudService(CloudService cloudService) {
		m_cloudService = cloudService;
	}

	public void unsetCloudService(CloudService cloudService) {
		m_cloudService = null;
	}
	
	public void setPositionService(PositionService positionService) {
		m_positionService = positionService;
	}
	
	public void unsetPositionService(PositionService positionService) {
		m_positionService = null;
	}
	
	protected void activate(ComponentContext componentContext, Map<String, Object> properties) {

        s_logger.info("Bundle " + APP_ID + " has started with config!");
        try {
			m_reliagateLed.setState(Led.BOTTOM, LedState.ON);
			m_reliagateLed.setState(Led.TOP, LedState.ON);
			
			// Acquire a Cloud Application Client for this Application 
			s_logger.info("Getting CloudClient for {}...", APP_ID);
			m_cloudClient = m_cloudService.newCloudClient(APP_ID);
			m_cloudClient.addCloudClientListener(this);
			
			updated(properties);
		} catch (EsfException e) {
			e.printStackTrace();
		}
  }
	
	protected void deactivate(ComponentContext componentContext) {
		
		s_logger.info("Deactivating " + APP_ID + " ...");
		try {
			m_reliagateLed.setState(Led.BOTTOM, LedState.OFF);
			m_reliagateLed.setState(Led.TOP, LedState.OFF);
		} catch (EsfException e) {
			e.printStackTrace();
		}
		
		// stop delayed shutdown thread
		if ((m_delayedShutdownTask != null) && !m_delayedShutdownTask.isCancelled()) {
			s_logger.debug("deactivate() :: Stopping delayedShutdownTask thread");
			boolean status = m_delayedShutdownTask.cancel(true);
			if (status) {
				s_logger.debug("deactivate() :: delayedShutdownTask thread stopped");
			}
			m_delayedShutdownTask = null;
		}
		
		// stop monitor thread
		if ((m_monitorTask != null) && !m_monitorTask.isCancelled()) {
			s_logger.debug("deactivate() :: Stopping monitor thread");
			boolean status = m_monitorTask.cancel(true);
			if (status) {
				s_logger.debug("deactivate() :: Monitor thread stopped");
			}
			m_monitorTask = null;
		}
		
		// Releasing the CloudApplicationClient
		s_logger.info("Releasing CloudApplicationClient for {}...", APP_ID);
		m_cloudClient.release();
				
		m_reliagateLed = null;
		m_ignitionSensor = null;
		m_adcReader = null;
		
		 s_logger.info("Deactivating " + APP_ID + " ... Done!");
	}
	
	public void updated(Map<String, Object> properties) {

		s_logger.info("Updated ReliaGATE I/O monitor ...");
		if (properties != null && !properties.isEmpty()) {
			Iterator<Entry<String, Object>> it = properties.entrySet()
					.iterator();

			while (it.hasNext()) {
				Entry<String, Object> entry = it.next();
				s_logger.trace("New property - " + entry.getKey() + " = "
						+ entry.getValue() + " of type "
						+ entry.getValue().getClass().toString());
			}
			
			// store the properties received
			m_configPollInterval = ((Integer)properties.get(POLL_INTERVAL_PROP_NAME)).intValue();
			m_configNormalShutdownDelay = ((Integer)properties.get(NORMAL_SHUTDOWN_DELAY_PROP_NAME)).intValue();
			m_configBatteryUndervoltageThreshold = ((Float)properties.get(BATTERY_UNDERVOLTAGE_THRESHOLD_PROP_NAME)).floatValue();
			m_configPublishEnabled = ((Boolean)properties.get(PUBLISH_ENABLED_PROP_NAME)).booleanValue();
			m_configPublishSemanticTopic = (String)properties.get(PUBLISH_TOPIC_PROP_NAME);
			m_configPublishQos = ((Integer)properties.get(PUBLISH_QOS_PROP_NAME)).intValue();
			m_configPublishRetain = ((Boolean)properties.get(PUBLISH_RETAIN_PROP_NAME)).booleanValue();
			int adcNum = ((Integer)properties.get(USE_ADC_PROP_NAME)).intValue();
			switch (adcNum) {
			case 1:
				m_useAdc = Adc.One;
				break;
			case 2: 
				m_useAdc = Adc.One;
				break;
			default:
				m_useAdc = DFLT_USE_ADC;	
			}
			
			// stop delayed shutdown thread
			if ((m_delayedShutdownTask != null) && !m_delayedShutdownTask.isCancelled()) {
				s_logger.debug("updated() :: Stopping delayedShutdownTask thread");
				boolean status = m_delayedShutdownTask.cancel(true);
				if (status) {
					s_logger.debug("updated() :: delayedShutdownTask thread stopped");
				}
				m_delayedShutdownTask = null;
			}
			
			// stop monitor thread
			if ((m_monitorTask != null) && !m_monitorTask.isCancelled()) {
				s_logger.debug("updated() :: Stopping monitor thread");
				boolean status = m_monitorTask.cancel(true);
				if (status) {
					s_logger.debug("updated() :: Monitor thread stopped");
				}
			}
			
			s_logger.debug("updated() :: Starting monitor thread");
			ScheduledThreadPoolExecutor executor = new ScheduledThreadPoolExecutor(1);
			m_monitorTask = executor.scheduleAtFixedRate(new Runnable() {
	    		@Override
	    		public void run() {
	    			Thread.currentThread().setName("IgnitionMonitor");
	    			monitor();
	    	}}, 0, m_configPollInterval, TimeUnit.SECONDS);
		}
	}
	
	@Override
	public void onControlMessageArrived(String deviceId, String appTopic,
			EsfPayload msg, int qos, boolean retain) {
		s_logger.info("Control Message arrived :: deviceID={} :: topic={}", deviceId, appTopic);
	}

	@Override
	public void onMessageArrived(String deviceId, String appTopic,
			EsfPayload msg, int qos, boolean retain) {
		s_logger.info("Message arrived :: deviceID={} :: topic={}", deviceId, appTopic);
	}

	@Override
	public void onConnectionLost() {
		s_logger.info("Connection lost");
	}

	@Override
	public void onConnectionEstablished() {
		s_logger.info("Connection established");
	}

	@Override
	public void onMessageConfirmed(int messageId, String appTopic) {
		s_logger.info("Message confirmed :: messageID={} :: topic={}", messageId, appTopic);
	}

	@Override
	public void onMessagePublished(int messageId, String appTopic) {
		s_logger.info("Message published :: messageID={} :: topic={}", messageId, appTopic);
	}
	
	private void monitor () {
		
		boolean isIgnitionOn = false;
		boolean isUnderVoltage = false;
		float batteryVoltage = -1;
		
		try {
			isIgnitionOn = m_ignitionSensor.isIgnitionOn();
			batteryVoltage = m_adcReader.getVoltage(m_useAdc);
			isUnderVoltage = ((batteryVoltage >= 0) && (batteryVoltage < this.m_configBatteryUndervoltageThreshold))? true : false;
			s_logger.debug("ignitionOn: " + isIgnitionOn);
			s_logger.debug("batteryVoltage: " + batteryVoltage);
			s_logger.debug("underVoltage? : " + isUnderVoltage);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		if (m_configPublishEnabled) {
			if ((isIgnitionOn != m_isIgnitionOn) || (isUnderVoltage != m_isUnderVoltage)) {
				doPublish(isIgnitionOn, isUnderVoltage, batteryVoltage, m_positionService.getNmeaPosition());
			}
			m_isIgnitionOn = isIgnitionOn;
			m_isUnderVoltage = isUnderVoltage;
		}
		
		if (isIgnitionOn) {
			if ((m_delayedShutdownTask != null) && !m_delayedShutdownTask.isCancelled()) {
				s_logger.debug("monitor :: ignition ON :: Stopping delayedShutdownTask");
				boolean status = m_delayedShutdownTask.cancel(true);
				if (status) {
					s_logger.debug("monitor :: ignition ON :: delayedShutdownTask stopped");
				}
				m_delayedShutdownTask = null;
			}
 		} else {
			int shutdownDelay = m_configNormalShutdownDelay;
			TimeUnit timeUnit = TimeUnit.SECONDS;
			if (isUnderVoltage) {
				// shutdown now
				shutdownDelay = 10;
				timeUnit = TimeUnit.MILLISECONDS;
				if ((m_delayedShutdownTask != null) && !m_delayedShutdownTask.isCancelled()) {
					s_logger.debug("monitor :: undervoltage :: Stopping delayedShutdownTask");
					boolean status = m_delayedShutdownTask.cancel(true);
					if (status) {
						s_logger.debug("monitor :: undervoltage :: delayedShutdownTask stopped");
					}
					m_delayedShutdownTask = null;
				}
			}
			
			if (m_delayedShutdownTask == null) {
				s_logger.warn("Scheduling 'shutdown' thread in " + shutdownDelay + " " + timeUnit.toString());
				ScheduledThreadPoolExecutor executor = new ScheduledThreadPoolExecutor(1);
				m_delayedShutdownTask = executor.schedule(new Runnable() {
			    	@Override
			    	public void run() {
			    		doShutdown();
			    	}
			    }, shutdownDelay, timeUnit);
			}
		} 
	}
	
	private void doPublish(boolean isIgnitionOn, boolean isUndervaoltage, float voltage, NmeaPosition position) {				
		
		// set message payload
		EsfPayload payload = new EsfPayload();
		payload.setTimestamp(new Date());
		payload.addMetric(METRICS_IS_IGNITION_ON, new Boolean(isIgnitionOn));
		payload.addMetric(METRICS_IS_UNDERVOLTAGE, new Boolean(isUndervaoltage));
		payload.addMetric(METRICS_BATERY_VOLTAGE, new Float(voltage));
		if (position != null) {
			payload.addMetric(METRICS_POSITION_LATITUDE, new Double(position.getLatitude()));
			payload.addMetric(METRICS_POSITION_LONGITUDE, new Double(position.getLongitude()));
			payload.addMetric(METRICS_POSITION_SPEED_MPH, new Double(position.getSpeedMph()));
		}
		
		// Publish the message
		try {
			m_cloudClient.publish(m_configPublishSemanticTopic, payload, m_configPublishQos, m_configPublishRetain);
			s_logger.debug("Published to {} message: {}", m_configPublishSemanticTopic, payload);
		} catch (Exception e) {
			s_logger.error("Cannot publish topic: " + m_configPublishSemanticTopic, e);
		}
	}
	
	private void doShutdown() {
		s_logger.warn("!!! Shutting System Down !!!");
		try {
			Runtime rt = Runtime.getRuntime();
			rt.exec("poweroff");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
